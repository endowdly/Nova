# --------------------------------------------------------------------------------------------------
# Nova Launcher
# --------------------------------------------------------------------------------------------------

#Requires -Version 5.0

<#
.Synopsis
  Launcher that uses Nova.
.Description
  Launcher that uses Nova. This script does not let you source it. It can only be invoked.
.Link
  ./nova.ps1
#>

#region Startup ---------------------------------------------------------------------------------------------------

# Forbid Sourcing
if ($MyInvocation.InvocationName -eq '.' -or $MyInvocation.Line -eq '') {
    Write-Warning 'Nova was sourced! This is verboten to prevent session pollution!'

    'ABORT'
    exit 1
}

$NurseryPath = Join-Path $PSScriptRoot Build
$ConfigPath = Join-Path $NurseryPath config.psd1
$Options = (Microsoft.PowerShell.Utility\Import-PowerShellDataFile $ConfigPath).LauncherOptions


# Dangit!
# unit -> unit
function Oops {
    exit 0
}


# Invokes a task
# string -> unit
function Invoke-Task ($s) {
    & $PSScriptRoot/nova.ps1 -Task $s
}


# Creates a new Host.ChoiceDescription object
# string -> char -> hashtable -> ChoiceDescription
# string -> char -> string -> ChoiceDescription
function New-Choice {
    param (
        [string] $Name,
        [char] $Token,
        [hashtable] $Dictionary,
        [string] $Message = ''
    )

    $label = $Name.Insert($Name.IndexOf($Token), '&')
    $msg =
    if ($null -ne $Dictionary) {
        $Dictionary.$Name
    }
    else {
        $Message
    }

    [System.Management.Automation.Host.ChoiceDescription]::new($label, $msg)
}


# Prompts the host for choices
# string -> string -> ChoiceDescription[] -> int -> int
function Read-Prompt {
    param (
        [string] $Title = '',
        [string] $Prompt,
        [System.Management.Automation.Host.ChoiceDescription[]] $Choices,
        [int] $DefaultChoice = 0
    )

    $Host.UI.PromptForChoice($Title, $Prompt, $Choices, $DefaultChoice)
}

# Converts an array into an ordered dictionary
# hashtable[] -> OrderedDictionary
function ConvertTo-ChoiceDictionary ($a) {
    $hash = [ordered] @{}

    $a | 
        Sort-Object { $_.Order } |
        Foreach-Object {
            [void] $hash.Add($_.Task, $_.HelpMessage)
        }

    $hash
}


# Adds an exit option to any orded hashtable
# OrderedDictionary -> OrderedDictionary
filter Add-Exit {
    [void] $_.Add('Exit', 'Abort this process')
    $_
}

# Builds a switch statement to handle results
# string -> hashtable[] -> scriptblock
function New-SwitchingBlock ($s, $a) {
    $sb = [System.Text.StringBuilder]::new("switch (`$$s) {`n")
    $append = {
        $str = "$( $_.Order ) { Invoke-Task $( $_.Task ) }"

        [void] $sb.AppendLine($str)
    }
    
    $a.Foreach($append)
    [void] $sb.AppendLine('default { Oops }')
    [void] $sb.AppendLine('}')

    [scriptblock]::Create($sb)
}

function Get-DefaultTask ($a) {

   foreach ($item in $a) {
       
       if ($item.Default) {
           return $item.Order
       }
   } 
}

# Converts a hashtable into a choicedescription array
# hashtable -> ChoiceDescription[]
function Get-Choice ($x) {
    $tokens = @{
        Key             = ''
        TokenIndex      = 0
        Token           = ''
        TokenCollection = [System.Collections.ArrayList]::new()
    }

    foreach ($k in $x.Keys) {
        $tokens |
            Set-Key $k |
            Set-TokenIndex 0 |
            Add-Token

        New-Choice -Name $k -Token $tokens.Token -Dictionary $x
    }
}


# Set the TokenIndex property on a token obj
# obj -> obj
filter Set-TokenIndex ($i) {
    $_.TokenIndex = $i
    $_
}


# Set the Key property on a token obj
# obj -> obj
filter Set-Key ($s) {
    $_.Key = $s
    $_
}

# Add a Token property to a collection on a token obj
# Tries not to allow repeat tokens
# obj -> obj
filter Add-Token {
    $_.Token = $_.Key.Substring($_.TokenIndex, 1)

    if ($_.Token -in $_.TokenCollection) {
        $_.TokenIndex++
        $_ | Add-Token
    }

    [void] $_.TokenCollection.Add($_.Token)
}


#endregion

#region Exeq ------------------------------------------------------------------------------------------------------

@"

            _
           ' )    )
           //   /'
         /'/  /' ____   .     ,   ____
       /' / /' /'    )--|    /  /'    )
     /'  //' /'    /'   |  /' /'    /'
 (,/'    (_,(___,/'    _|/(__(___,/(__

Running Java $( (Get-Command Java).Version )
Running $( & ./bin/asciidoctorj.bat --version )

"@

$Choices = ConvertTo-ChoiceDictionary $Options | Add-Exit
$ContinueChoices = [Ordered] @{
    Yes = 'Continue to complete another Action'
    No  = 'End this Process'
}
$Actions = @{
    Prompt  = 'Choose Action'
    Choices = Get-Choice $Choices
    Default = Get-DefaultTask $Options
}
$Continue = @{
    Prompt  = 'Would you like to run another Action?'
    Choices = Get-Choice $ContinueChoices
    Default = 1
}

do {
    $result = Read-Prompt -Prompt $Actions.Prompt -Choices $Actions.Choices -DefaultChoice $Actions.Default

    (New-SwitchingBlock result $LauncherOptions).Invoke()

    $canContinue = Read-Prompt -Prompt $Continue.Prompt -Choices $Continue.Choices -DefaultChoice $Continue.Default
} until ($canContinue -eq 1)

#endregion
